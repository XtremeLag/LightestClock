# UltraLight Clock Widget (12-Hour Format)

The lightest possible Android clock widget with **12-hour AM/PM format**.

## Features
- 12-hour format with AM/PM indicator
- Seconds display
- Date display (Day, Mon Date)
- Pure Kotlin, zero dependencies
- Custom Canvas drawing
- Updates every minute via AlarmManager
- Minimal battery usage

## Size Target
**< 50 KB APK**

## Build
1. Open in Android Studio
2. Build → Generate Signed Bundle/APK
3. Upload AAB to Play Store

## License
MIT
