# Keep widget provider
-keep class com.example.ultralightclock.ClockWidget { *; }
-keep class com.example.ultralightclock.ClockUpdateReceiver { *; }
