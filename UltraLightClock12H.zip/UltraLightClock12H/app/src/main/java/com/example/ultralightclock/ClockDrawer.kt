package com.example.ultralightclock

import android.appwidget.AppWidgetManager
import android.content.Context
import android.graphics.*
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.*

object ClockDrawer {
    private const val WIDGET_WIDTH = 440
    private const val WIDGET_HEIGHT = 180

    fun update(context: Context, manager: AppWidgetManager, widgetId: Int) {
        val bitmap = Bitmap.createBitmap(WIDGET_WIDTH, WIDGET_HEIGHT, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        drawBackground(canvas)
        drawTime12H(canvas)
        drawDate(canvas)

        val views = RemoteViews(context.packageName, R.layout.widget).apply {
            setImageViewBitmap(R.id.clock_image, bitmap)
        }
        manager.updateAppWidget(widgetId, views)
    }

    private fun drawBackground(canvas: Canvas) {
        canvas.drawColor(Color.parseColor("#1A1A1A"))
        val paint = Paint().apply {
            color = Color.parseColor("#333333")
            style = Paint.Style.STROKE
            strokeWidth = 4f
        }
        canvas.drawRect(2f, 2f, WIDGET_WIDTH - 2f, WIDGET_HEIGHT - 2f, paint)
    }

    private fun drawTime12H(canvas: Canvas) {
        val calendar = Calendar.getInstance()
        val hour = calendar.get(Calendar.HOUR)
        val displayHour = if (hour == 0) 12 else hour
        val minute = calendar.get(Calendar.MINUTE)
        val amPm = calendar.get(Calendar.AM_PM)
        val amPmText = if (amPm == Calendar.AM) "AM" else "PM"

        // Format time as "hh:mm" with leading zero for minute
        val timeText = String.format("%d:%02d", displayHour, minute)

        // Draw time
        val timePaint = Paint().apply {
            color = Color.WHITE
            textSize = 96f
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }
        val timeBounds = Rect()
        timePaint.getTextBounds(timeText, 0, timeText.length, timeBounds)
        val timeX = (WIDGET_WIDTH - timeBounds.width()) / 2f - 30f
        val timeY = WIDGET_HEIGHT * 0.55f
        canvas.drawText(timeText, timeX, timeY, timePaint)

        // Draw AM/PM indicator
        val amPmPaint = Paint().apply {
            color = Color.parseColor("#4CAF50")
            textSize = 28f
            isAntiAlias = true
            typeface = Typeface.DEFAULT_BOLD
        }
        canvas.drawText(amPmText, timeX + timeBounds.width() + 20f, timeY - 10f, amPmPaint)

        // Draw seconds (small, below AM/PM)
        val sec = String.format("%02d", calendar.get(Calendar.SECOND))
        val secPaint = Paint().apply {
            color = Color.parseColor("#888888")
            textSize = 24f
            isAntiAlias = true
        }
        canvas.drawText(sec, timeX + timeBounds.width() + 25f, timeY + 25f, secPaint)
    }

    private fun drawDate(canvas: Canvas) {
        val date = SimpleDateFormat("EEE, MMM d", Locale.getDefault()).format(Date())
        val paint = Paint().apply {
            color = Color.parseColor("#AAAAAA")
            textSize = 28f
            isAntiAlias = true
        }
        val bounds = Rect()
        paint.getTextBounds(date, 0, date.length, bounds)
        val x = (WIDGET_WIDTH - bounds.width()) / 2f
        val y = WIDGET_HEIGHT * 0.85f
        canvas.drawText(date, x, y, paint)
    }
}
