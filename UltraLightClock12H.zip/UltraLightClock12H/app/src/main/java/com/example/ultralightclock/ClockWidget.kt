package com.example.ultralightclock

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context

class ClockWidget : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        appWidgetManager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        for (appWidgetId in appWidgetIds) {
            ClockDrawer.update(context, appWidgetManager, appWidgetId)
        }
        AlarmHelper.set(context)
    }

    override fun onEnabled(context: Context) {
        AlarmHelper.set(context)
    }

    override fun onDisabled(context: Context) {
        AlarmHelper.cancel(context)
    }
}
